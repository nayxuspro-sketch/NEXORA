// Récupérer l'URL API :
// 1. Variable d'environnement explicite
// 2. Si exécuté dans le navigateur, utiliser le proxy local relatif /api/v1 (fonctionne quel que soit le port Django)
// 3. Repli standard sur http://127.0.0.1:8008/api/v1
const API_BASE =
  process.env.NEXT_PUBLIC_API_URL ||
  (typeof window !== 'undefined' ? '/api/v1' : 'http://127.0.0.1:8008/api/v1');

export class ApiError extends Error {
  code: string;
  details: any;
  status: number;

  constructor(message: string, code = 'api_error', details: any = null, status = 400) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.details = details;
    this.status = status;
  }
}

export async function apiRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = typeof window !== 'undefined'
    ? (sessionStorage.getItem('nexora_session_token') || sessionStorage.getItem('nexora_access_token') || localStorage.getItem('nexora_access_token'))
    : null;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token && token.startsWith('eyJ')) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;

  // Essayer successivement le proxy relatif Next.js puis le direct localhost:8008
  const targets = [
    `/api/v1${cleanEndpoint}`,
    `http://127.0.0.1:8008/api/v1${cleanEndpoint}`,
    `http://127.0.0.1:8000/api/v1${cleanEndpoint}`
  ];

  let lastError: any = null;
  for (const url of targets) {
    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      const rawText = await response.text();
      let data: any = {};
      try {
        data = JSON.parse(rawText);
      } catch {
        // Réponse non-JSON
        continue;
      }

      if (response.status === 401 || response.status === 403) {
        throw new ApiError(
          'Acces refuse par le serveur : session expiree ou droits insuffisants.'
          + ' Reconnectez-vous, puis reessayez. Rien n\'a ete simule.',
          'session_refusee',
          data,
          response.status
        );
      }

      if (!response.ok) {
        throw new ApiError(
          data.message || data.error || data.detail || 'Erreur lors de l\'opération.',
          data.code || 'request_failed',
          data.details || data,
          response.status
        );
      }

      return data as T;
    } catch (err: any) {
      if (err instanceof ApiError) throw err;
      lastError = err;
    }
  }

  // Avant : si le backend ne repondait pas, un enregistrement etait simule en
  // memoire et l'ecran affichait un succes. En caisse, cela revenait a croire
  // une vente enregistree alors qu'elle n'existait nulle part. Une panne doit
  // se voir, pas etre masquee.
  throw new ApiError(
    'Le serveur backend n\'est pas joignable (essaye : proxy /api/v1, puis 127.0.0.1:8008, puis 127.0.0.1:8000). '
    + 'RIEN n\'a ete enregistre : demarrez le backend avec start-local.bat, puis reessayez.',
    'backend_offline',
    null,
    503
  );
}
