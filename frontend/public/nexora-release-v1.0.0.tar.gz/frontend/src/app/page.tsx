'use client';

import * as React from 'react';
import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/layout/dashboard-layout';
import { KpiCard } from '@/components/ui/kpi-card';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { SimpleBarChart } from '@/components/ui/simple-chart';
import { formatCurrency } from '@/lib/utils';
import { apiRequest } from '@/lib/api';
import { DashboardReport } from '@/types';
import {
  TrendingUp,
  ShoppingCart,
  AlertTriangle,
  Wallet,
  ArrowUpRight,
  ShieldAlert,
  Layers,
  ArrowRight
} from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function DashboardPage() {
  const { data: report, isLoading } = useQuery<DashboardReport>({
    queryKey: ['dashboard-report'],
    queryFn: () => apiRequest<DashboardReport>('/reports/dashboard/?days=30'),
    placeholderData: {
      period_days: 30,
      sales: {
        total_amount: '24850000.00',
        count: 142,
        tax_collected: '4473000.00',
        discounts_granted: '350000.00',
      },
      purchases: {
        total_amount: '16200000.00',
        count: 18,
      },
      profitability: {
        gross_estimate: '8650000.00',
      },
      inventory: {
        total_units_stocked: '1840.00',
        low_stock_alerts_count: 3,
        low_stock_items: [
          {
            product_id: 'p1',
            product_name: 'Ordinateur Portable HP ProBook 15',
            sku: 'LAPTOP-HP-01',
            store_name: 'Magasin & Dépôt Ouaga Central',
            current_stock: '2.00',
            alert_threshold: '5.00',
          },
          {
            product_id: 'p2',
            product_name: 'Souris Sans Fil Ergonomique Rechargeable',
            sku: 'MOUSE-WL-01',
            store_name: 'Magasin & Dépôt Ouaga Central',
            current_stock: '4.00',
            alert_threshold: '10.00',
          },
        ],
      },
    },
  });

  const chartData = [
    { label: 'Lun', value: 2450000 },
    { label: 'Mar', value: 3800000 },
    { label: 'Mer', value: 2900000 },
    { label: 'Jeu', value: 4500000 },
    { label: 'Ven', value: 5800000 },
    { label: 'Sam', value: 7200000 },
    { label: 'Dim', value: 3200000 },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header section */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-foreground">
              Tableau de bord de Gestion
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Vue d'ensemble stratégique : <span className="font-semibold text-primary">Vente → Gestion → Anticipation</span>
            </p>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="/GUIDE_UTILISATEUR.pdf"
              download="NEXORA_Guide_Utilisateur.pdf"
              className="inline-flex items-center justify-center rounded-lg font-bold text-xs px-3 py-2 bg-indigo-600 text-white hover:bg-indigo-700 shadow-md transition-all gap-1.5"
            >
              📥 Télécharger Guide (PDF)
            </a>
            <a
              href="/GUIDE_DEPLOIEMENT.html"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center rounded-lg font-bold text-xs px-3 py-2 bg-slate-800 text-white hover:bg-slate-900 shadow-md transition-all gap-1.5"
            >
              📄 Déploiement
            </a>
            <Link href="/pos">
              <Button size="lg" className="w-full sm:w-auto shadow-md">
                <ShoppingCart className="h-4 w-4 mr-2" /> Ouvrir Caisse
              </Button>
            </Link>
          </div>
        </div>

        {/* Top KPI Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <KpiCard
            title="Chiffre d'Affaires (30j)"
            value={formatCurrency(report?.sales?.total_amount || '0')}
            change="+14.2%"
            changeType="positive"
            icon={<TrendingUp className="h-5 w-5" />}
            description={`${report?.sales?.count || 0} transactions complétées`}
          />
          <KpiCard
            title="Marge Brute Estimée"
            value={formatCurrency(report?.profitability?.gross_estimate || '0')}
            change="+8.6%"
            changeType="positive"
            icon={<Wallet className="h-5 w-5" />}
            description="Après déduction des coûts d'achats"
          />
          <KpiCard
            title="Unités en Stock"
            value={Number(report?.inventory?.total_units_stocked || 0).toLocaleString('fr-FR')}
            icon={<Layers className="h-5 w-5" />}
            description="Réparties sur tous vos dépôts"
          />
          <KpiCard
            title="Alertes Rupture Stock"
            value={report?.inventory?.low_stock_alerts_count || 0}
            change={Number(report?.inventory?.low_stock_alerts_count || 0) > 0 ? "Action requise" : "Optimal"}
            changeType={Number(report?.inventory?.low_stock_alerts_count || 0) > 0 ? "negative" : "positive"}
            icon={<AlertTriangle className="h-5 w-5" />}
            description="Articles sous le seuil d'alerte"
          />
        </div>

        {/* Mid section: Sales Graph & Low Stock Table */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <SimpleBarChart
              title="Évolution Hebdomadaire des Ventes (EUR)"
              data={chartData}
              height={220}
            />
          </div>

          <Card className="flex flex-col">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-base font-semibold flex items-center gap-2">
                <ShieldAlert className="h-4 w-4 text-amber-500" />
                Alertes de Réapprovisionnement
              </CardTitle>
              <Badge variant="warning">{report?.inventory?.low_stock_alerts_count} urgents</Badge>
            </CardHeader>
            <CardContent className="flex-1 space-y-4 pt-2">
              {report?.inventory?.low_stock_items?.length ? (
                report.inventory.low_stock_items.map((item) => (
                  <div
                    key={item.product_id}
                    className="p-3 rounded-lg border bg-muted/30 flex items-center justify-between"
                  >
                    <div>
                      <p className="text-sm font-semibold text-foreground">{item.product_name}</p>
                      <p className="text-xs text-muted-foreground">{item.sku} • {item.store_name}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-black text-rose-600 block">
                        {item.current_stock} pcs
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        Seuil: {item.alert_threshold}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-muted-foreground text-center py-8">Aucun stock sous le seuil critique.</p>
              )}

              <Link href="/inventory" className="mt-auto block">
                <Button variant="outline" size="sm" className="w-full text-xs">
                  Gérer les réapprovisionnements <ArrowRight className="h-3.5 w-3.5 ml-1" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
