import * as React from 'react';
import { Menu, Search, Bell, Moon, Sun, Command } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface TopbarProps {
  onToggleSidebar: () => void;
  onOpenQuickSearch: () => void;
}

export function Topbar({ onToggleSidebar, onOpenQuickSearch }: TopbarProps) {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 md:px-8 border-b border-border bg-card/80 backdrop-blur-md">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-lg text-muted-foreground hover:bg-muted lg:hidden"
        >
          <Menu className="h-5 w-5" />
        </button>

        {/* Global Quick Search trigger button */}
        <button
          onClick={onOpenQuickSearch}
          className="hidden md:flex items-center justify-between w-64 lg:w-96 px-3.5 py-1.5 text-xs text-muted-foreground bg-muted/50 border border-input rounded-lg hover:border-primary/50 transition-all text-left"
        >
          <div className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            <span>Rechercher produit, vente, client...</span>
          </div>
          <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-medium bg-background border rounded text-muted-foreground shadow-xs">
            <Command className="h-3 w-3" /> K
          </kbd>
        </button>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={onOpenQuickSearch}
          className="md:hidden p-2 rounded-lg text-muted-foreground hover:bg-muted"
        >
          <Search className="h-5 w-5" />
        </button>

        <button
          title="Notifications"
          className="relative p-2 rounded-lg text-muted-foreground hover:bg-muted transition-colors"
        >
          <Bell className="h-5 w-5" />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-primary" />
        </button>
      </div>
    </header>
  );
}
