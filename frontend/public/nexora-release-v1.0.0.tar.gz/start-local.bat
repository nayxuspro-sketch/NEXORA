@echo off
REM ==============================================================================
REM NEXORA ERP & POS - Installation & Demarrage Permanent (Windows)
REM Configure les serveurs en service permanent / arriere-plan au demarrage
REM ==============================================================================

title NEXORA Enterprise ERP - Installation & Demarrage

echo ==============================================================================
echo [NEXORA] Configuration et Lancement de la plateforme (Burkina Faso / FCFA)...
echo ==============================================================================

REM 1. Verification de Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] Python n'est pas installe ou n'est pas dans votre PATH.
    echo Veuillez installer Python 3.11+ depuis https://www.python.org/
    echo Pensez a cocher la case "Add Python to PATH" lors de l'installation.
    pause
    exit /b 1
)

REM 2. Verification de Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] Node.js n'a pas ete detecte.
    echo Veuillez installer Node.js depuis https://nodejs.org/ (LTS).
    pause
    exit /b 1
)

REM 3. Configuration initiale de Python (si pas encore fait)
if not exist .venv (
    echo [1/5] Creation de l'environnement virtuel Python...
    python -m venv .venv
)
echo [2/5] Verification des dependances Backend...
call .venv\Scripts\activate.bat
pip install -r requirements.txt --quiet

REM 4. Base de donnees & donnees initiales FCFA
echo [3/5] Migration et chargement des donnees de demonstration...
python manage.py migrate --noinput
python scripts\seed_data.py

REM 5. Dependances Frontend
cd frontend
if not exist node_modules (
    echo [4/5] Installation des dependances de l'interface Web...
    call npm install
)
cd ..

REM 6. Enregistrement du demarrage automatique permanent au demarrage de Windows
echo [5/5] Configuration du demarrage automatique en arriere-plan...

REM Ajout dans le dossier Demarrage Windows de l'utilisateur pour que NEXORA demarre avec le PC
set "STARTUP_FOLDER=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
copy /y "%~dp0scripts\run_background_servers.vbs" "%STARTUP_FOLDER%\NEXORA_Service.vbs" >nul 2>&1

REM 7. Lancement immediat des serveurs en arriere-plan
echo Lancement des serveurs en arriere-plan...
cscript //nologo "%~dp0scripts\run_background_servers.vbs"

REM 8. Ouverture automatique du navigateur
timeout /t 3 /nobreak >nul
start http://localhost:3000/

echo.
echo ==============================================================================
echo [SUCCES TOTAL] NEXORA est desormais installe et actif en continu !
echo.
echo - Les serveurs tournent silencieusement en arriere-plan.
echo - Ils redemarreront automatiquement a chaque allumage de votre ordinateur.
echo - Vous pouvez fermer cette fenetre : pour ouvrir l'application a tout moment,
echo   il vous suffit desormais de taper directement :
echo.
echo        >>>   http://localhost:3000/   <<<
echo.
echo ==============================================================================
pause
